node.default[:foo][:bar] = "100"
