default['sysstat']['settings'] = ::File.join ::File::SEPARATOR, "etc", "default", "sysstat"
default['sysstat']['enabled'] = "true"
