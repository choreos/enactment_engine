default[:ganglia][:cluster_name] = "CHOReOS"
default[:ganglia][:location] = "unspecified"
default[:ganglia][:owner] = "unspecified"
default[:ganglia][:latlong] = "unspecified"
default[:ganglia][:url] = "unspecified"
# Multicast has not been tested!
default[:ganglia][:unicast] = true
# The graphite server
default[:ganglia][:server_role] = "ganglia"
