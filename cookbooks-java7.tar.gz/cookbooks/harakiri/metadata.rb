maintainer       "CHOReOS"
maintainer_email "tfurtado@ime.usp.br, lago@ime.usp.br"
license          "bla"
description      "Deactivate a deployed JAR file running on a cloud node"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"


