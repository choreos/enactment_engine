# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/. 

default['monitoring']['tarball_server']  = "http://valinhos.ime.usp.br:54080/choreos"
default['monitoring']['tarball_name']    = "PlatformMonitoring"
default['monitoring']['tarball_version'] = "0.2-SNAPSHOT"
