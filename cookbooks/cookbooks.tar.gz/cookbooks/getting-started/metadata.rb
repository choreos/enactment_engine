maintainer       "Opscode, Inc."
maintainer_email "sysadmin@opscode.com"
license          "Apache 2.0"
description      "Used by the Getting Started guide at http://help.opscode.com and the Quick Start guides at wiki.opscode.com"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.3.0"
