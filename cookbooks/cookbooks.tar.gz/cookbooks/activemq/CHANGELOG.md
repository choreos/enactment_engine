## v1.1.0:

* [COOK-2816] - update version to 5.8.0
* [COOK-2817] - resolve foodcritic warning

## v1.0.2:

* [COOK-800] - activemq cookbook should install 5.5.1 by default
* [COOK-872] - activemq home directory isn't explicitly created
