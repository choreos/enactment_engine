This directory contains the cookbooks used to configure systems in your infrastructure with Chef.

